package com.tedu.sumary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SumaryApplication {

	public static void main(String[] args) {
		SpringApplication.run(SumaryApplication.class, args);
	}
}
